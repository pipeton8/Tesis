
TimeForFOCwrtRiskySharetDirect = 0
TimeForFOCwrtRiskySharetMat         = 0

TimeForRiskySharetDirect  = 0 
TimeForRiskySharetMat  = 0 

TimeForOmegasInvtDirect      = 0 
TimeForOmegasInvtMat   = 0 

TimeForOmegahInvtDirect      = 0 
TimeForOmegahInvtMat   = 0 

TimeForCertEquivDirect       = 0 
TimeForCertEquivMat    = 0 

TimeForOmegaInvtDirect      = 0 
TimeForOmegaInvtMat   = 0 

TimeForctDirect     = 0
TimeForctMat     = 0

TimeForVxInvtDirect    = 0
TimeForVxInvtMat = 0

TimeForVhInvtDirect    = 0
TimeForVhInvtMat = 0

TimeForVInvtDirect    = 0
TimeForVInvtMat = 0

TimeForFOCwrtRiskySharetList = 0
TimeForRiskySharetList  = 0 
TimeForOmegasInvtList      = 0 
TimeForOmegahInvtList      = 0 
TimeForCertEquivList       = 0 
TimeForOmegaInvtList      = 0 
TimeForctList     = 0
TimeForVxInvtList    = 0
TimeForVhInvtList    = 0
TimeForVInvtList    = 0

TimeForOmegastMatResults = 0;

TimeForArrayArgs = 0;

TimeForMatricesSetup = TimeForListsSetup = 0;


VariableTimeCostDirect = VariableTimeCostMat = VariableTimeCostList = 0;