MatrixForm[{{"ktLevel", 33.95342975566465}, {"ktRatio", 3.910101495901845}, 
  {"ktBot1PctRatio", 0.0028984316239671517}, 
  {"ktMedianRatio", 0.08561921688268946}, {"ktTop1PctRatio", 
   15.847286623230794}, {"MPCMeanQuarterly", 0.14609479036397938}, 
  {"MPCMeanAnnual", 0.468334288181543}, {"ktTopFrac", 0.971778668129619}, 
  {"kOwLTopMean", 11.517784294538068}, {"kOwLBotMean", 0.1646480637363872}}]
