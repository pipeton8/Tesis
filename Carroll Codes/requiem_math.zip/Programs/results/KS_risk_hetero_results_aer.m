MatrixForm[{{"ktLevel", 34.11211473928959}, {"ktRatio", 3.9158796681704393}, 
  {"ktBot1PctRatio", 0.064418949235775}, {"ktMedianRatio", 
   0.408821311630549}, {"ktTop1PctRatio", 15.186372205496495}, 
  {"MPCMeanQuarterly", 0.053386299118725}, {"MPCMeanAnnual", 
   0.1970451163304623}, {"ktTopFrac", 0.9409750791043686}, 
  {"kOwLTopMean", 11.086061976574934}, {"kOwLBotMean", 0.3464574717874477}}]
