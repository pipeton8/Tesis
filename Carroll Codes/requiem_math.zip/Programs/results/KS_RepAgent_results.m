MatrixForm[{{"ktLevel", 34.211186055775705}, {"ktRatio", 3.9285338811266213}, 
  {"MPCMeanQuarterly", 0.010954841119949071}, 
  {"MPCMeanAnnual", 0.04310455751209419}}]
