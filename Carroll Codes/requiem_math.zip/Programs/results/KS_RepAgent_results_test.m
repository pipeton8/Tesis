MatrixForm[{{"ktLevel", 34.26929936649978}, {"ktRatio", 3.932873310272672}, 
  {"MPCMeanQuarterly", 0.0108991162381399}, 
  {"MPCMeanAnnual", 0.04288888528879109}}]
