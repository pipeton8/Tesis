MatrixForm[{{"ktLevel", 33.93456829922583}, {"ktRatio", 3.9084685647187416}, 
  {"ktBot1PctRatio", 0.05558763669027328}, {"ktMedianRatio", 
   0.3987149420842269}, {"ktTop1PctRatio", 15.048525849005795}, 
  {"MPCMeanQuarterly", 0.05539255268249127}, 
  {"MPCMeanAnnual", 0.20383063830361758}, {"ktTopFrac", 0.9381961687925414}, 
  {"kOwLTopMean", 11.115838333110602}, {"kOwLBotMean", 0.3608674964056855}}]
