MatrixForm[{{"ktLevel", 34.560612703548124}, {"ktRatio", 3.956644726205864}, 
  {"ktBot1PctRatio", 1.9439908836717934}, {"ktMedianRatio", 
   3.912960086545531}, {"ktTop1PctRatio", 6.147991956806188}, 
  {"MPCMeanQuarterly", 0.011543726892491332}, 
  {"MPCMeanAnnual", 0.0453814971877331}, {"ktTopFrac", 0.4100989127798306}, 
  {"kOwLTopMean", 4.8946453825165985}, {"kOwLBotMean", 3.491263326648348}}]
