MatrixForm[{{"ktLevel", 33.99163460657367}, {"ktRatio", 3.910169017983294}, 
  {"ktBot1PctRatio", 0.06623769169513856}, {"ktMedianRatio", 
   0.43530815963581365}, {"ktTop1PctRatio", 14.783791116671328}, 
  {"MPCMeanQuarterly", 0.05033926750616036}, 
  {"MPCMeanAnnual", 0.18665664478103916}, {"ktTopFrac", 0.9330014245432067}, 
  {"kOwLTopMean", 11.05979868336825}, {"kOwLBotMean", 0.3912304432127394}}]
