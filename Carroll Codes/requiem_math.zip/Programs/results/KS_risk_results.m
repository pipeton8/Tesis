MatrixForm[{{"ktLevel", 34.68790468284195}, {"ktRatio", 3.963255275856624}, 
  {"ktBot1PctRatio", 1.9137573844250955}, {"ktMedianRatio", 
   3.907094182599151}, {"ktTop1PctRatio", 6.196558263170862}, 
  {"MPCMeanQuarterly", 0.011533168918810491}, 
  {"MPCMeanAnnual", 0.04534071036170739}, {"ktTopFrac", 0.4139921193624539}, 
  {"kOwLTopMean", 4.9502376575688425}, {"kOwLBotMean", 3.475433025089221}}]
