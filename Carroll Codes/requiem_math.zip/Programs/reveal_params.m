
Print["{gamma,catchup,rho,beta,Rcertain,G,etZeroProbVals,DepreciationRate,etUnempProb,UnempWage} = "
,{gamma,catchup,rho,beta[[-1,1]],Rcertain,G[[-1,1,1]],etZeroProbVals,Depreciation,etUnempProb,UnempWage}];