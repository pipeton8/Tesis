
newSave["ergodic.sav",NumOfsGridStates];
newSave["ergodic.sav",sTransMatrixByAggState];
newSave["ergodic.sav",sErgodicDist];
newSave["ergodic.sav",sErgodicArray];
newSave["ergodic.sav",sDist];
newSave["ergodic.sav",sDistCum];
newSave["ergodic.sav",sDistByEmpState];
newSave["ergodic.sav",EmpDist];
newSave["ergodic.sav",sMeanByEmpState];


newSave["ergodic.sav",NumOfxGridStates];
newSave["ergodic.sav",xTransMatrixByAggState];
newSave["ergodic.sav",xErgodicDist];
newSave["ergodic.sav",xErgodicArray];
newSave["ergodic.sav",xDist];
newSave["ergodic.sav",xDistCum];
newSave["ergodic.sav",xDistByEmpState];
newSave["ergodic.sav",xMeanByEmpState];
